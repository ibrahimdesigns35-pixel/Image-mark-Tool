// ============================================
// Image Mark Tool - Contact Form Handler
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const subject = document.getElementById('subject').value;
            const message = document.getElementById('message').value.trim();
            
            // Validate form
            if (!validateForm(name, email, message)) {
                return;
            }
            
            // Simulate form submission (replace with actual backend endpoint)
            submitForm(name, email, subject, message);
        });
    }
    
    // ============================================
    // FORM VALIDATION
    // ============================================
    function validateForm(name, email, message) {
        // Name validation
        if (name.length < 2) {
            showFormMessage('Please enter a valid name (at least 2 characters)', 'error');
            return false;
        }
        
        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            showFormMessage('Please enter a valid email address', 'error');
            return false;
        }
        
        // Message validation
        if (message.length < 10) {
            showFormMessage('Please enter a message (at least 10 characters)', 'error');
            return false;
        }
        
        return true;
    }
    
    // ============================================
    // FORM SUBMISSION
    // ============================================
    function submitForm(name, email, subject, message) {
        const formMessage = document.getElementById('formMessage');
        const submitButton = contactForm.querySelector('button[type="submit"]');
        
        // Disable submit button and show loading state
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
        
        // Simulate API call (replace with actual backend endpoint)
        setTimeout(() => {
            // Success simulation
            showFormMessage('Thank you for your message! We\'ll get back to you within 24-48 hours.', 'success');
            
            // Reset form
            contactForm.reset();
            
            // Re-enable submit button
            submitButton.disabled = false;
            submitButton.innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
            
            // Show notification
            showNotification('Message sent successfully!');
            
            // In a real application, you would make an AJAX request here:
            /*
            fetch('/api/contact', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    name: name,
                    email: email,
                    subject: subject,
                    message: message
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showFormMessage('Thank you for your message! We\'ll get back to you soon.', 'success');
                    contactForm.reset();
                } else {
                    showFormMessage('Something went wrong. Please try again.', 'error');
                }
                submitButton.disabled = false;
                submitButton.innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
            })
            .catch(error => {
                showFormMessage('Network error. Please try again later.', 'error');
                submitButton.disabled = false;
                submitButton.innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
            });
            */
            
        }, 1500); // Simulate network delay
    }
    
    // ============================================
    // FORM MESSAGE DISPLAY
    // ============================================
    function showFormMessage(message, type) {
        const formMessage = document.getElementById('formMessage');
        
        if (formMessage) {
            formMessage.textContent = message;
            formMessage.className = 'form-message ' + type;
            formMessage.style.display = 'block';
            
            // Auto-hide error messages after 5 seconds
            if (type === 'error') {
                setTimeout(() => {
                    formMessage.style.display = 'none';
                }, 5000);
            }
        }
    }
    
    // ============================================
    // REAL-TIME VALIDATION
    // ============================================
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const messageInput = document.getElementById('message');
    
    if (nameInput) {
        nameInput.addEventListener('blur', function() {
            if (this.value.trim().length < 2 && this.value.length > 0) {
                this.style.borderColor = '#ef4444';
            } else if (this.value.trim().length >= 2) {
                this.style.borderColor = '#10b981';
            } else {
                this.style.borderColor = '';
            }
        });
        
        nameInput.addEventListener('focus', function() {
            this.style.borderColor = '#26c7bc';
        });
    }
    
    if (emailInput) {
        emailInput.addEventListener('blur', function() {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(this.value) && this.value.length > 0) {
                this.style.borderColor = '#ef4444';
            } else if (emailRegex.test(this.value)) {
                this.style.borderColor = '#10b981';
            } else {
                this.style.borderColor = '';
            }
        });
        
        emailInput.addEventListener('focus', function() {
            this.style.borderColor = '#26c7bc';
        });
    }
    
    if (messageInput) {
        messageInput.addEventListener('blur', function() {
            if (this.value.trim().length < 10 && this.value.length > 0) {
                this.style.borderColor = '#ef4444';
            } else if (this.value.trim().length >= 10) {
                this.style.borderColor = '#10b981';
            } else {
                this.style.borderColor = '';
            }
        });
        
        messageInput.addEventListener('focus', function() {
            this.style.borderColor = '#26c7bc';
        });
    }
    
    // ============================================
    // CHARACTER COUNTER FOR MESSAGE
    // ============================================
    if (messageInput) {
        const counterDiv = document.createElement('div');
        counterDiv.style.cssText = `
            text-align: right;
            font-size: 0.875rem;
            color: #6b7280;
            margin-top: 0.25rem;
        `;
        messageInput.parentNode.appendChild(counterDiv);
        
        messageInput.addEventListener('input', function() {
            const length = this.value.length;
            counterDiv.textContent = `${length} characters`;
            
            if (length >= 10) {
                counterDiv.style.color = '#10b981';
            } else {
                counterDiv.style.color = '#6b7280';
            }
        });
    }
    
});