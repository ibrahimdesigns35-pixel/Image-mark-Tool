// ============================================
// Image Mark Tool - Watermark Functionality
// Core image processing and watermarking
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    
    // ============================================
    // 1. GLOBAL VARIABLES
    // ============================================
    let originalImage = null;
    let logoImage = null;
    let canvas = document.getElementById('canvas');
    let ctx = canvas ? canvas.getContext('2d') : null;
    
    const uploadArea = document.getElementById('uploadArea');
    const editorArea = document.getElementById('editorArea');
    const imageInput = document.getElementById('imageInput');
    const logoInput = document.getElementById('logoInput');
    
    // Watermark settings
    let watermarkSettings = {
        text: '© Your Brand',
        fontSize: 36,
        fontFamily: 'Arial',
        fontColor: '#ffffff',
        opacity: 50,
        rotation: 0,
        position: 'center',
        logoSize: 100,
        logoOpacity: 80,
        logoPosition: 'bottom-right',
        logoRotation: 0
    };
    
    // ============================================
    // 2. FILE UPLOAD HANDLING
    // ============================================
    
    // Click to upload
    if (uploadArea && imageInput) {
        uploadArea.addEventListener('click', function() {
            imageInput.click();
        });
        
        // Drag and drop
        uploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('drag-over');
        });
        
        uploadArea.addEventListener('dragleave', function(e) {
            e.preventDefault();
            this.classList.remove('drag-over');
        });
        
        uploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('drag-over');
            
            const file = e.dataTransfer.files[0];
            if (file && file.type.match('image.*')) {
                loadImage(file);
            } else {
                showNotification('Please upload a valid image file', 'error');
            }
        });
        
        // File input change
        imageInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                loadImage(file);
            }
        });
    }
    
    // Logo upload
    if (logoInput) {
        logoInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                loadLogo(file);
            }
        });
    }
    
    // ============================================
    // 3. IMAGE LOADING
    // ============================================
    function loadImage(file) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            originalImage = new Image();
            originalImage.onload = function() {
                initializeCanvas();
                showNotification('Image loaded successfully!');
            };
            originalImage.src = e.target.result;
        };
        
        reader.onerror = function() {
            showNotification('Error loading image', 'error');
        };
        
        reader.readAsDataURL(file);
    }
    
    function loadLogo(file) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            logoImage = new Image();
            logoImage.onload = function() {
                drawWatermark();
                showNotification('Logo loaded successfully!');
            };
            logoImage.src = e.target.result;
        };
        
        reader.onerror = function() {
            showNotification('Error loading logo', 'error');
        };
        
        reader.readAsDataURL(file);
    }
    
    // ============================================
    // 4. CANVAS INITIALIZATION
    // ============================================
    function initializeCanvas() {
        if (!canvas || !originalImage) return;
        
        // Set canvas size to match image
        const maxWidth = 800;
        const maxHeight = 600;
        let width = originalImage.width;
        let height = originalImage.height;
        
        // Scale down if image is too large
        if (width > maxWidth || height > maxHeight) {
            const ratio = Math.min(maxWidth / width, maxHeight / height);
            width = width * ratio;
            height = height * ratio;
        }
        
        canvas.width = originalImage.width;
        canvas.height = originalImage.height;
        canvas.style.maxWidth = '100%';
        canvas.style.height = 'auto';
        
        // Show editor area, hide upload area
        if (uploadArea && editorArea) {
            uploadArea.style.display = 'none';
            editorArea.style.display = 'block';
        }
        
        // Draw initial watermark
        drawWatermark();
    }
    
    // ============================================
    // 5. WATERMARK DRAWING
    // ============================================
    function drawWatermark() {
        if (!canvas || !ctx || !originalImage) return;
        
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Draw original image
        ctx.drawImage(originalImage, 0, 0, canvas.width, canvas.height);
        
        // Get active tab
        const activeTab = document.querySelector('.tab-btn.active');
        const isTextWatermark = activeTab && activeTab.getAttribute('data-tab') === 'text';
        
        if (isTextWatermark) {
            drawTextWatermark();
        } else {
            drawLogoWatermark();
        }
    }
    
    function drawTextWatermark() {
        if (!ctx) return;
        
        const text = watermarkSettings.text;
        const fontSize = watermarkSettings.fontSize;
        const fontFamily = watermarkSettings.fontFamily;
        const color = watermarkSettings.fontColor;
        const opacity = watermarkSettings.opacity / 100;
        const rotation = watermarkSettings.rotation * (Math.PI / 180);
        
        // Calculate position
        const position = getTextPosition();
        
        // Save context state
        ctx.save();
        
        // Set font and style
        ctx.font = `${fontSize}px ${fontFamily}`;
        ctx.fillStyle = color;
        ctx.globalAlpha = opacity;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        // Apply rotation
        ctx.translate(position.x, position.y);
        ctx.rotate(rotation);
        
        // Draw text with shadow for better visibility
        ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        ctx.shadowBlur = 4;
        ctx.shadowOffsetX = 2;
        ctx.shadowOffsetY = 2;
        ctx.fillText(text, 0, 0);
        
        // Restore context state
        ctx.restore();
    }
    
    function drawLogoWatermark() {
        if (!ctx || !logoImage) return;
        
        const size = watermarkSettings.logoSize;
        const opacity = watermarkSettings.logoOpacity / 100;
        const rotation = watermarkSettings.logoRotation * (Math.PI / 180);
        
        // Calculate position
        const position = getLogoPosition(size);
        
        // Save context state
        ctx.save();
        
        // Set opacity
        ctx.globalAlpha = opacity;
        
        // Apply rotation
        ctx.translate(position.x + size / 2, position.y + size / 2);
        ctx.rotate(rotation);
        
        // Draw logo
        const aspectRatio = logoImage.width / logoImage.height;
        const logoWidth = size;
        const logoHeight = size / aspectRatio;
        
        ctx.drawImage(logoImage, -logoWidth / 2, -logoHeight / 2, logoWidth, logoHeight);
        
        // Restore context state
        ctx.restore();
    }
    
    // ============================================
    // 6. POSITION CALCULATION
    // ============================================
    function getTextPosition() {
        const padding = 50;
        let x, y;
        
        switch (watermarkSettings.position) {
            case 'top-left':
                x = padding;
                y = padding;
                break;
            case 'top-center':
                x = canvas.width / 2;
                y = padding;
                break;
            case 'top-right':
                x = canvas.width - padding;
                y = padding;
                break;
            case 'middle-left':
                x = padding;
                y = canvas.height / 2;
                break;
            case 'center':
                x = canvas.width / 2;
                y = canvas.height / 2;
                break;
            case 'middle-right':
                x = canvas.width - padding;
                y = canvas.height / 2;
                break;
            case 'bottom-left':
                x = padding;
                y = canvas.height - padding;
                break;
            case 'bottom-center':
                x = canvas.width / 2;
                y = canvas.height - padding;
                break;
            case 'bottom-right':
                x = canvas.width - padding;
                y = canvas.height - padding;
                break;
            default:
                x = canvas.width / 2;
                y = canvas.height / 2;
        }
        
        return { x, y };
    }
    
    function getLogoPosition(size) {
        const padding = 30;
        let x, y;
        
        switch (watermarkSettings.logoPosition) {
            case 'top-left':
                x = padding;
                y = padding;
                break;
            case 'top-center':
                x = (canvas.width - size) / 2;
                y = padding;
                break;
            case 'top-right':
                x = canvas.width - size - padding;
                y = padding;
                break;
            case 'middle-left':
                x = padding;
                y = (canvas.height - size) / 2;
                break;
            case 'center':
                x = (canvas.width - size) / 2;
                y = (canvas.height - size) / 2;
                break;
            case 'middle-right':
                x = canvas.width - size - padding;
                y = (canvas.height - size) / 2;
                break;
            case 'bottom-left':
                x = padding;
                y = canvas.height - size - padding;
                break;
            case 'bottom-center':
                x = (canvas.width - size) / 2;
                y = canvas.height - size - padding;
                break;
            case 'bottom-right':
                x = canvas.width - size - padding;
                y = canvas.height - size - padding;
                break;
            default:
                x = canvas.width - size - padding;
                y = canvas.height - size - padding;
        }
        
        return { x, y };
    }
    
    // ============================================
    // 7. EVENT LISTENERS FOR CONTROLS
    // ============================================
    
    // Text watermark controls
    const textInput = document.getElementById('watermarkText');
    if (textInput) {
        textInput.addEventListener('input', function() {
            watermarkSettings.text = this.value;
            drawWatermark();
        });
    }
    
    const fontSizeInput = document.getElementById('fontSize');
    if (fontSizeInput) {
        fontSizeInput.addEventListener('input', function() {
            watermarkSettings.fontSize = parseInt(this.value);
            drawWatermark();
        });
    }
    
    const fontColorInput = document.getElementById('fontColor');
    if (fontColorInput) {
        fontColorInput.addEventListener('input', function() {
            watermarkSettings.fontColor = this.value;
            drawWatermark();
        });
    }
    
    const opacityInput = document.getElementById('opacity');
    if (opacityInput) {
        opacityInput.addEventListener('input', function() {
            watermarkSettings.opacity = parseInt(this.value);
            drawWatermark();
        });
    }
    
    const rotationInput = document.getElementById('rotation');
    if (rotationInput) {
        rotationInput.addEventListener('input', function() {
            watermarkSettings.rotation = parseInt(this.value);
            drawWatermark();
        });
    }
    
    const fontFamilySelect = document.getElementById('fontFamily');
    if (fontFamilySelect) {
        fontFamilySelect.addEventListener('change', function() {
            watermarkSettings.fontFamily = this.value;
            drawWatermark();
        });
    }
    
    // Logo watermark controls
    const logoSizeInput = document.getElementById('logoSize');
    if (logoSizeInput) {
        logoSizeInput.addEventListener('input', function() {
            watermarkSettings.logoSize = parseInt(this.value);
            drawWatermark();
        });
    }
    
    const logoOpacityInput = document.getElementById('logoOpacity');
    if (logoOpacityInput) {
        logoOpacityInput.addEventListener('input', function() {
            watermarkSettings.logoOpacity = parseInt(this.value);
            drawWatermark();
        });
    }
    
    const logoRotationInput = document.getElementById('logoRotation');
    if (logoRotationInput) {
        logoRotationInput.addEventListener('input', function() {
            watermarkSettings.logoRotation = parseInt(this.value);
            drawWatermark();
        });
    }
    
    // Position buttons for text
    const positionButtons = document.querySelectorAll('.position-btn:not(.logo-pos)');
    positionButtons.forEach(button => {
        button.addEventListener('click', function() {
            positionButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            watermarkSettings.position = this.getAttribute('data-position');
            drawWatermark();
        });
    });
    
    // Position buttons for logo
    const logoPositionButtons = document.querySelectorAll('.position-btn.logo-pos');
    logoPositionButtons.forEach(button => {
        button.addEventListener('click', function() {
            logoPositionButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            watermarkSettings.logoPosition = this.getAttribute('data-position');
            drawWatermark();
        });
    });
    
    // Tab switching trigger redraw
    const tabButtons = document.querySelectorAll('.tab-btn');
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            setTimeout(() => drawWatermark(), 100);
        });
    });
    
});

// ============================================
// 8. RESET IMAGE
// ============================================
function resetImage() {
    const uploadArea = document.getElementById('uploadArea');
    const editorArea = document.getElementById('editorArea');
    const imageInput = document.getElementById('imageInput');
    
    if (uploadArea && editorArea) {
        uploadArea.style.display = 'block';
        editorArea.style.display = 'none';
    }
    
    if (imageInput) {
        imageInput.value = '';
    }
    
    showNotification('Reset complete. Upload a new image to continue.');
}

// ============================================
// 9. DOWNLOAD IMAGE
// ============================================
function downloadImage() {
    const canvas = document.getElementById('canvas');
    if (!canvas) {
        showNotification('No image to download', 'error');
        return;
    }
    
    try {
        // Create download link
        const link = document.createElement('a');
        const timestamp = new Date().getTime();
        link.download = `watermarked-image-${timestamp}.png`;
        
        // Convert canvas to blob for better quality
        canvas.toBlob(function(blob) {
            const url = URL.createObjectURL(blob);
            link.href = url;
            link.click();
            
            // Clean up
            setTimeout(() => URL.revokeObjectURL(url), 100);
            
            showNotification('Image downloaded successfully!');
        }, 'image/png', 1.0);
        
    } catch (error) {
        console.error('Download error:', error);
        showNotification('Error downloading image', 'error');
    }
}